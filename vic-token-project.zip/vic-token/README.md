# VIC Token Deployment

## Install

```bash
npm install
```

## Add your private key

Create a `.env` file:

```env
PRIVATE_KEY=your_wallet_private_key
```

## Compile

```bash
npm run compile
```

## Deploy

```bash
npm run deploy
```

Network:
- OPN Testnet
- Chain ID: 984
