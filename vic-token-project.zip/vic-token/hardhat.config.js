require("@nomicfoundation/hardhat-toolbox");
require("dotenv").config();

module.exports = {
  solidity: "0.8.20",
  networks: {
    opn: {
      url: "https://testnet-rpc.iopn.tech",
      chainId: 984,
      accounts: [process.env.PRIVATE_KEY]
    }
  }
};
